package com.tsc.service;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class FileUploadService {

    private final String filesPath = "files";

    private final Path rootLocation;

    public FileUploadService() {
        this.rootLocation = Paths.get(filesPath);
    }

    @PostConstruct
    public void initService() {
        deleteAll();
        init();
    }

    public String storeFile(MultipartFile file) throws IOException {

        if (file.isEmpty()) {
            return "";
        }
        String fileName = file.getOriginalFilename();
        fileName = fileName.replace(fileName.substring(0, fileName.lastIndexOf(".")),
                UUID.randomUUID().toString());
        Path filePath = rootLocation.resolve(fileName)
                .normalize()
                .toAbsolutePath();

        try (InputStream inputStream= file.getInputStream()){
            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ioException) {
            throw new RuntimeException("Failed to store file");
        }
        return fileName;
    }

    public Resource loadFile(String fileName) throws IOException {
        try {
            Path file = rootLocation.resolve(fileName);
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            }
        } catch (IOException ioException) {
            throw new IOException("File cannot be loaded");
        }
        throw new IOException("File cannot be loaded");
    }

    public void deleteAll() {
        FileSystemUtils.deleteRecursively(rootLocation.toFile());
    }

    public void init() {
        try {
            Files.createDirectories(rootLocation);
        }
        catch (IOException e) {
            throw new RuntimeException("Could not initialize storage", e);
        }
    }

}
